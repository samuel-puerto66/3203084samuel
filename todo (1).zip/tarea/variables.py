from operacion.datos3 import b,c
from resultado.datos2 import a
print (a+b+c)