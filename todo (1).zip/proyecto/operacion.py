from variable.dato import a,b
print (a+b)